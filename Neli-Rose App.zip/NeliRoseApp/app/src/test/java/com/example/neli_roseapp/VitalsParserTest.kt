package com.example.neli_roseapp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VitalsParserTest {

    @Test
    fun parsesBloodPressureIntoSystolicAndDiastolic() {
        val result = VitalsParser.parse("120/80", "", "", "")
        assertEquals(120, result.systolic)
        assertEquals(80, result.diastolic)
    }

    @Test
    fun ignoresUnitsAfterHeartRate() {
        assertEquals(72, VitalsParser.parse("", "72 bpm", "", "").heartRate)
    }

    @Test
    fun acceptsCommaAsDecimalSeparator() {
        val result = VitalsParser.parse("", "", "36,6", "68,5")
        assertEquals(36.6, result.temperatureC!!, 0.001)
        assertEquals(68.5, result.weightKg!!, 0.001)
    }

    @Test
    fun emptyOrInvalidInputGivesNulls() {
        val result = VitalsParser.parse("", "abc", "  ", "n/a")
        assertTrue(result.isEmpty())
        assertNull(result.heartRate)
    }

    @Test
    fun systolicOnlyIsAccepted() {
        val result = VitalsParser.parse("135", "", "", "")
        assertEquals(135, result.systolic)
        assertNull(result.diastolic)
    }
}

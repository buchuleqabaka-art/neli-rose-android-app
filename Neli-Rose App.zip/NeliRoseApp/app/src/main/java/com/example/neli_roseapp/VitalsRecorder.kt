package com.example.neli_roseapp

import android.content.Context
import com.example.neli_roseapp.api.ApiClient
import com.example.neli_roseapp.api.VitalsRequest
import com.example.neli_roseapp.db.NeliDatabase
import com.example.neli_roseapp.db.VitalsHistoryEntity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException

// Called when the resident taps "Save Vitals":
// 1) stores the reading in the local Room history table, 2) sends it to the REST API.
object VitalsRecorder {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun record(
        context: Context,
        bp: String,
        hr: String,
        temp: String,
        weight: String,
        onResult: (String) -> Unit
    ) {
        val appContext = context.applicationContext
        val parsed = VitalsParser.parse(bp, hr, temp, weight)
        if (parsed.isEmpty()) {
            onResult("Please enter at least one vital sign.")
            return
        }

        val uid = runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull() ?: "default_user"
        val recordedAt = System.currentTimeMillis()

        scope.launch {
            DataManager.ensureProfileRow(appContext)
            runCatching {
                NeliDatabase.getInstance(appContext).vitalsHistoryDao().insert(
                    VitalsHistoryEntity(
                        userId = uid,
                        systolic = parsed.systolic,
                        diastolic = parsed.diastolic,
                        heartRate = parsed.heartRate,
                        temperatureC = parsed.temperatureC,
                        weightKg = parsed.weightKg,
                        recordedAt = recordedAt
                    )
                )
            }

            val message = try {
                val response = ApiClient.service.postVitals(
                    VitalsRequest(
                        systolic = parsed.systolic,
                        diastolic = parsed.diastolic,
                        heartRate = parsed.heartRate,
                        temperature = parsed.temperatureC,
                        weightKg = parsed.weightKg,
                        recordedAt = recordedAt
                    )
                )
                "Vitals saved and synced. Status: ${response.status ?: "recorded"}"
            } catch (e: HttpException) {
                when (e.code()) {
                    401 -> "Vitals saved on this phone. Please sign in again to sync."
                    400 -> "Vitals saved on this phone. The server rejected a value - please check the numbers."
                    else -> "Vitals saved on this phone. Server error (${e.code()})."
                }
            } catch (e: Exception) {
                "Vitals saved on this phone. Could not reach the server."
            }

            withContext(Dispatchers.Main) { onResult(message) }
        }
    }
}

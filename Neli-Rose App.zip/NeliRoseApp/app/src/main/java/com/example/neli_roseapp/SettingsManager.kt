package com.example.neli_roseapp

import android.content.Context
import android.content.res.Configuration

// Stores the Settings screen choices (text size, notifications)
object SettingsManager {

    private const val PREFS = "neli_settings"
    private const val KEY_TEXT_SIZE = "text_size_index"
    private const val KEY_NOTIFICATIONS = "notifications_enabled"

    // 0 = Normal, 1 = Large, 2 = Extra large
    private val multipliers = floatArrayOf(1.0f, 1.2f, 1.4f)

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getTextSizeIndex(context: Context): Int =
        prefs(context).getInt(KEY_TEXT_SIZE, 0).coerceIn(0, multipliers.size - 1)

    fun setTextSizeIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_TEXT_SIZE, index.coerceIn(0, multipliers.size - 1)).apply()
    }

    fun notificationsEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_NOTIFICATIONS, true)

    fun setNotificationsEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_NOTIFICATIONS, enabled).apply()
    }

    // Use inside attachBaseContext() so the chosen text size is applied on top of the phone's own setting
    fun wrap(base: Context): Context {
        val multiplier = multipliers[getTextSizeIndex(base)]
        if (multiplier == 1.0f) return base
        val config = Configuration(base.resources.configuration)
        config.fontScale = config.fontScale * multiplier
        return base.createConfigurationContext(config)
    }
}

package com.example.neli_roseapp.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// Parent table: one row per resident (userId = Firebase uid)
@Entity(tableName = "user_profiles")
data class UserProfileEntity(
    @PrimaryKey val userId: String,
    val fullName: String,
    val phone: String,
    val email: String
)

// Latest vitals snapshot (one row per resident, updated as they type)
@Entity(
    tableName = "vitals",
    foreignKeys = [
        ForeignKey(
            entity = UserProfileEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class VitalsEntity(
    @PrimaryKey val userId: String,
    val bp: String,
    val hr: String,
    val temp: String,
    val weight: String,
    val hydrationGlasses: Int
)

// NEW: permanent history of every saved reading, with proper numeric types
@Entity(
    tableName = "vitals_history",
    foreignKeys = [
        ForeignKey(
            entity = UserProfileEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId", "recordedAt"])]
)
data class VitalsHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val systolic: Int?,
    val diastolic: Int?,
    val heartRate: Int?,
    val temperatureC: Double?,
    val weightKg: Double?,
    val recordedAt: Long
)

@Entity(
    tableName = "medications",
    foreignKeys = [
        ForeignKey(
            entity = UserProfileEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId"])]
)
data class MedicationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val name: String,
    val time: String,
    val taken: Boolean
)

@Entity(
    tableName = "schedule_events",
    foreignKeys = [
        ForeignKey(
            entity = UserProfileEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId"])]
)
data class ScheduleEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val time: String,
    val title: String,
    val note: String,
    val done: Boolean
)

@Entity(
    tableName = "activities",
    foreignKeys = [
        ForeignKey(
            entity = UserProfileEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId"])]
)
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val time: String,
    val name: String,
    val place: String,
    val joined: Boolean
)

@Entity(
    tableName = "contacts",
    foreignKeys = [
        ForeignKey(
            entity = UserProfileEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId"])]
)
data class ContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val name: String,
    val phone: String
)

package com.example.neli_roseapp

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.neli_roseapp.api.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Shows announcements from the care team, loaded from the Neli-Rose REST API
class AnnouncementsActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(SettingsManager.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcements)

        findViewById<ImageView>(R.id.btnAnnouncementsBack).setOnClickListener { finish() }

        val progress = findViewById<ProgressBar>(R.id.progressAnnouncements)
        val container = findViewById<LinearLayout>(R.id.announcementsContainer)
        val tvStatus = findViewById<TextView>(R.id.tvAnnouncementsStatus)
        val dateFormat = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())

        lifecycleScope.launch {
            try {
                val items = withContext(Dispatchers.IO) { ApiClient.service.announcements() }
                progress.visibility = View.GONE
                if (items.isEmpty()) {
                    tvStatus.text = "No announcements right now."
                    tvStatus.visibility = View.VISIBLE
                    return@launch
                }
                val pad = (16 * resources.displayMetrics.density).toInt()
                val gap = (12 * resources.displayMetrics.density).toInt()
                items.forEach { item ->
                    val card = LinearLayout(this@AnnouncementsActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setBackgroundResource(R.drawable.bg_card)
                        setPadding(pad, pad, pad, pad)
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = gap }
                    }
                    card.addView(TextView(this@AnnouncementsActivity).apply {
                        text = item.title
                        textSize = 18f
                        setTextColor(getColor(R.color.neli_green))
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                    })
                    card.addView(TextView(this@AnnouncementsActivity).apply {
                        text = dateFormat.format(Date(item.createdAt))
                        textSize = 13f
                        setTextColor(getColor(R.color.neli_text_hint))
                    })
                    card.addView(TextView(this@AnnouncementsActivity).apply {
                        text = item.message
                        textSize = 16f
                        setTextColor(getColor(R.color.neli_text_dark))
                        setPadding(0, gap / 2, 0, 0)
                    })
                    container.addView(card)
                }
            } catch (e: Exception) {
                progress.visibility = View.GONE
                tvStatus.text = "Could not load announcements.\nCheck your connection and that the API is running."
                tvStatus.visibility = View.VISIBLE
            }
        }
    }
}

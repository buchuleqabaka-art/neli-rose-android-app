package com.example.neli_roseapp.api

import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiConfig {
    // Android emulator: 10.0.2.2 is your computer's localhost.
    // Physical phone + USB: run `adb reverse tcp:3000 tcp:3000` and use "http://localhost:3000/".
    // Deployed server: use its https address, e.g. "https://neli-rose-api.onrender.com/".
    const val BASE_URL = "http://10.0.2.2:3000/"
}

object ApiClient {

    // Adds the signed-in user's Firebase ID token to every request.
    // Interceptors run on OkHttp's background threads, so waiting for the token here is safe.
    private val authInterceptor = Interceptor { chain ->
        val builder = chain.request().newBuilder()
        val user = runCatching { FirebaseAuth.getInstance().currentUser }.getOrNull()
        if (user != null) {
            val token = runCatching {
                Tasks.await(user.getIdToken(false), 10, TimeUnit.SECONDS).token
            }.getOrNull()
            if (token != null) builder.header("Authorization", "Bearer $token")
        }
        chain.proceed(builder.build())
    }

    private val okHttp: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(authInterceptor)
            // BASIC logs only "POST /api/vitals 201" - never headers or bodies (no tokens or health data)
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
            .build()
    }

    val service: NeliApiService by lazy {
        Retrofit.Builder()
            .baseUrl(ApiConfig.BASE_URL)
            .client(okHttp)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(NeliApiService::class.java)
    }
}

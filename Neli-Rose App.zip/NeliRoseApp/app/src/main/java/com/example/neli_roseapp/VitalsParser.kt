package com.example.neli_roseapp

data class ParsedVitals(
    val systolic: Int?,
    val diastolic: Int?,
    val heartRate: Int?,
    val temperatureC: Double?,
    val weightKg: Double?
) {
    fun isEmpty() = systolic == null && diastolic == null && heartRate == null &&
            temperatureC == null && weightKg == null
}

// Turns the text the resident typed ("120/80", "72 bpm", "36,6") into real numbers
object VitalsParser {

    private val numberRegex = Regex("""\d+(?:[.,]\d+)?""")

    private fun firstNumber(text: String): Double? =
        numberRegex.find(text)?.value?.replace(',', '.')?.toDoubleOrNull()

    fun parse(bp: String, hr: String, temp: String, weight: String): ParsedVitals {
        val bpNumbers = numberRegex.findAll(bp).map { it.value.substringBefore('.').substringBefore(',') }.toList()
        return ParsedVitals(
            systolic = bpNumbers.getOrNull(0)?.toIntOrNull(),
            diastolic = bpNumbers.getOrNull(1)?.toIntOrNull(),
            heartRate = firstNumber(hr)?.toInt(),
            temperatureC = firstNumber(temp),
            weightKg = firstNumber(weight)
        )
    }
}

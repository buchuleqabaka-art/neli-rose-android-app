package com.example.neli_roseapp.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert

@Dao
interface UserDao {
    // Upsert (not REPLACE): REPLACE deletes the row first, which would cascade-delete
    // all of the resident's meds, events and contacts now that foreign keys exist.
    @Upsert
    suspend fun insertProfile(profile: UserProfileEntity)

    // Used to make sure the parent row exists before child rows are written
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertProfileIfMissing(profile: UserProfileEntity)

    @Query("SELECT * FROM user_profiles WHERE userId = :userId LIMIT 1")
    suspend fun getProfile(userId: String): UserProfileEntity?
}

@Dao
interface VitalsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVitals(vitals: VitalsEntity)

    @Query("SELECT * FROM vitals WHERE userId = :userId LIMIT 1")
    suspend fun getVitals(userId: String): VitalsEntity?
}

@Dao
interface VitalsHistoryDao {
    @Insert
    suspend fun insert(reading: VitalsHistoryEntity): Long

    @Query("SELECT * FROM vitals_history WHERE userId = :userId ORDER BY recordedAt DESC LIMIT :limit")
    suspend fun getRecent(userId: String, limit: Int): List<VitalsHistoryEntity>
}

@Dao
interface MedicationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeds(meds: List<MedicationEntity>)

    @Query("DELETE FROM medications WHERE userId = :userId")
    suspend fun deleteMedsForUser(userId: String)

    @Query("SELECT * FROM medications WHERE userId = :userId")
    suspend fun getMeds(userId: String): List<MedicationEntity>
}

@Dao
interface ScheduleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<ScheduleEventEntity>)

    @Query("DELETE FROM schedule_events WHERE userId = :userId")
    suspend fun deleteEventsForUser(userId: String)

    @Query("SELECT * FROM schedule_events WHERE userId = :userId ORDER BY time ASC")
    suspend fun getEvents(userId: String): List<ScheduleEventEntity>
}

@Dao
interface ActivityDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivities(activities: List<ActivityEntity>)

    @Query("DELETE FROM activities WHERE userId = :userId")
    suspend fun deleteActivitiesForUser(userId: String)

    @Query("SELECT * FROM activities WHERE userId = :userId")
    suspend fun getActivities(userId: String): List<ActivityEntity>
}

@Dao
interface ContactDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContacts(contacts: List<ContactEntity>)

    @Query("DELETE FROM contacts WHERE userId = :userId")
    suspend fun deleteContactsForUser(userId: String)

    @Query("SELECT * FROM contacts WHERE userId = :userId")
    suspend fun getContacts(userId: String): List<ContactEntity>
}

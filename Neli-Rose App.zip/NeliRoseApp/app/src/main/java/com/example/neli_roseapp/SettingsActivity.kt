package com.example.neli_roseapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import com.example.neli_roseapp.api.ApiClient
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(SettingsManager.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val user = runCatching { FirebaseAuth.getInstance().currentUser }.getOrNull()
        val uid = user?.uid ?: "default_user"
        val email = user?.email ?: ""

        findViewById<ImageView>(R.id.btnSettingsBack).setOnClickListener { finish() }

        // ---- Profile ----
        val etName = findViewById<EditText>(R.id.etSettingsName)
        val etPhone = findViewById<EditText>(R.id.etSettingsPhone)
        val tvEmail = findViewById<TextView>(R.id.tvSettingsEmail)
        // DataManager keeps the phone in this SharedPreferences file under "<uid>_phone"
        val userPrefs = getSharedPreferences("neli_user_prefs", MODE_PRIVATE)

        etName.setText(DataManager.getUserName(this))
        etPhone.setText(userPrefs.getString("${uid}_phone", ""))
        tvEmail.text = if (email.isBlank()) "Not available" else email

        findViewById<Button>(R.id.btnSaveProfile).setOnClickListener {
            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            if (name.isBlank()) {
                etName.error = "Please enter your name"
                return@setOnClickListener
            }
            if (phone.isNotBlank() && phone.count { it.isDigit() } < 9) {
                etPhone.error = "Enter a valid phone number"
                return@setOnClickListener
            }
            DataManager.saveUserProfile(this, name, phone, email)
            if (user != null) {
                runCatching {
                    FirebaseFirestore.getInstance().collection("users").document(uid)
                        .set(mapOf("fullName" to name, "phone" to phone), SetOptions.merge())
                }
            }
            Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show()
        }

        // ---- Text size ----
        val rgTextSize = findViewById<RadioGroup>(R.id.rgTextSize)
        val ids = listOf(R.id.rbTextNormal, R.id.rbTextLarge, R.id.rbTextExtraLarge)
        rgTextSize.check(ids[SettingsManager.getTextSizeIndex(this)])
        rgTextSize.setOnCheckedChangeListener { _, checkedId ->
            val index = ids.indexOf(checkedId)
            if (index >= 0 && index != SettingsManager.getTextSizeIndex(this)) {
                SettingsManager.setTextSizeIndex(this, index)
                recreate() // re-draw this screen with the new size
            }
        }

        // ---- Notifications ----
        val switchNotifications = findViewById<SwitchCompat>(R.id.switchNotifications)
        switchNotifications.isChecked = SettingsManager.notificationsEnabled(this)
        switchNotifications.setOnCheckedChangeListener { _, enabled ->
            SettingsManager.setNotificationsEnabled(this, enabled)
            runCatching {
                if (enabled) FirebaseMessaging.getInstance().subscribeToTopic("residents")
                else FirebaseMessaging.getInstance().unsubscribeFromTopic("residents")
            }
            Toast.makeText(
                this,
                if (enabled) "Care alerts turned on" else "Care alerts turned off",
                Toast.LENGTH_SHORT
            ).show()
        }

        // ---- Care team / API ----
        findViewById<Button>(R.id.btnAnnouncements).setOnClickListener {
            startActivity(Intent(this, AnnouncementsActivity::class.java))
        }
        findViewById<Button>(R.id.btnTestApi).setOnClickListener {
            lifecycleScope.launch {
                val message = try {
                    val result = withContext(Dispatchers.IO) { ApiClient.service.health() }
                    "Server connected: ${result.status}"
                } catch (e: Exception) {
                    "Cannot reach the server. Check that the API is running."
                }
                Toast.makeText(this@SettingsActivity, message, Toast.LENGTH_LONG).show()
            }
        }

        // ---- Account ----
        findViewById<Button>(R.id.btnChangePassword).setOnClickListener {
            if (email.isBlank()) {
                Toast.makeText(this, "No email address on this account", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    val msg = if (task.isSuccessful) "Password reset link sent to $email"
                    else "Could not send the reset email. Try again later."
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
        }
        findViewById<Button>(R.id.btnViewData).setOnClickListener { RoomDataViewer.show(this) }

        // ---- About ----
        val versionName = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }
            .getOrNull() ?: "1.0"
        findViewById<TextView>(R.id.tvVersion).text = "Neli-Rose App  |  Version $versionName"

        // ---- Log out ----
        findViewById<Button>(R.id.btnSettingsLogout).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Log out")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Log out") { _, _ ->
                    runCatching { FirebaseAuth.getInstance().signOut() }
                    val intent = Intent(this, LoginActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}

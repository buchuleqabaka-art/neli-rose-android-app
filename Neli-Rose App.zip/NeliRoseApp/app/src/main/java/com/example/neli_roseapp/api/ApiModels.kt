package com.example.neli_roseapp.api

data class HealthResponse(val status: String, val service: String?, val time: String?)

data class Announcement(
    val id: String,
    val title: String,
    val message: String,
    val createdAt: Long
)

data class VitalsRequest(
    val systolic: Int?,
    val diastolic: Int?,
    val heartRate: Int?,
    val temperature: Double?,
    val weightKg: Double?,
    val recordedAt: Long
)

data class VitalsResponse(
    val id: String,
    val systolic: Int?,
    val diastolic: Int?,
    val heartRate: Int?,
    val temperature: Double?,
    val weightKg: Double?,
    val recordedAt: Long,
    val status: String?
)

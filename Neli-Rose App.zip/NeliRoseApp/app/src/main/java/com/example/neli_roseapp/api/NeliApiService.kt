package com.example.neli_roseapp.api

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

// Endpoints of the Neli-Rose REST API (see the /server folder)
interface NeliApiService {

    @GET("api/health")
    suspend fun health(): HealthResponse

    @GET("api/announcements")
    suspend fun announcements(): List<Announcement>

    @GET("api/vitals")
    suspend fun vitals(@Query("limit") limit: Int): List<VitalsResponse>

    @POST("api/vitals")
    suspend fun postVitals(@Body body: VitalsRequest): VitalsResponse
}

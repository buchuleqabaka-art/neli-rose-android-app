package com.example.neli_roseapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.google.firebase.messaging.FirebaseMessaging

object FcmHelper {
    const val CHANNEL_ID = "neli_care_alerts"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Care Alerts & Announcements"
            val descriptionText = "Notifications for care alerts and resident announcements"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun registerDevice() {
        runCatching {
            FirebaseMessaging.getInstance().subscribeToTopic("residents")
        }
    }
}

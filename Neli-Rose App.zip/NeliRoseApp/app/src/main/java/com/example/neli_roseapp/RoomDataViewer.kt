package com.example.neli_roseapp

import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.neli_roseapp.db.NeliDatabase
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Shows what is stored in the local Room database (used from Settings and the header title)
object RoomDataViewer {

    fun show(activity: AppCompatActivity) {
        val db = NeliDatabase.getInstance(activity)
        val uid = runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull() ?: "default_user"

        activity.lifecycleScope.launch(Dispatchers.IO) {
            val profile = db.userDao().getProfile(uid)
            val vitals = db.vitalsDao().getVitals(uid)
            val history = db.vitalsHistoryDao().getRecent(uid, 5)
            val meds = db.medicationDao().getMeds(uid)
            val contacts = db.contactDao().getContacts(uid)
            val events = db.scheduleDao().getEvents(uid)

            val sb = StringBuilder()
            sb.append("User Profile:\n")
            sb.append("- Name: ${profile?.fullName ?: "N/A"}\n")
            sb.append("- Email: ${profile?.email ?: "N/A"}\n")
            sb.append("- Phone: ${profile?.phone ?: "N/A"}\n\n")

            sb.append("Current vitals:\n")
            sb.append("- BP: ${vitals?.bp ?: "N/A"} | HR: ${vitals?.hr ?: "N/A"}\n")
            sb.append("- Temp: ${vitals?.temp ?: "N/A"} | Weight: ${vitals?.weight ?: "N/A"}\n\n")

            sb.append("Saved readings (latest ${history.size}):\n")
            if (history.isEmpty()) sb.append("- None yet\n")
            else history.forEach {
                sb.append("- ${it.systolic ?: "?"}/${it.diastolic ?: "?"} mmHg, ${it.heartRate ?: "?"} bpm, " +
                        "${it.temperatureC ?: "?"} C, ${it.weightKg ?: "?"} kg\n")
            }
            sb.append("\n")

            sb.append("Medications (${meds.size}):\n")
            if (meds.isEmpty()) sb.append("- None saved\n")
            else meds.forEach { sb.append("- ${it.name} (${it.time})\n") }
            sb.append("\n")

            sb.append("Contacts (${contacts.size}):\n")
            if (contacts.isEmpty()) sb.append("- None saved\n")
            else contacts.forEach { sb.append("- ${it.name}: ${it.phone}\n") }
            sb.append("\n")

            sb.append("Schedule events (${events.size}):\n")
            if (events.isEmpty()) sb.append("- None saved\n")
            else events.forEach { sb.append("- ${it.title} at ${it.time}\n") }

            withContext(Dispatchers.Main) {
                if (!activity.isFinishing) {
                    AlertDialog.Builder(activity)
                        .setTitle("Room Database Records")
                        .setMessage(sb.toString())
                        .setPositiveButton("Close", null)
                        .show()
                }
            }
        }
    }
}

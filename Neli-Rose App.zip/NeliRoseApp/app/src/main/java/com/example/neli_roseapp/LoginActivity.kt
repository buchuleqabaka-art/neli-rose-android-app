package com.example.neli_roseapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.credentials.CreatePasswordRequest
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetPasswordOption
import androidx.credentials.PasswordCredential
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private var auth: FirebaseAuth? = null
    private val webClientId = "487739624548-ggpdu5b15v6cbhie1rffv0lmib3gus42.apps.googleusercontent.com"
    private lateinit var googleSignInClient: GoogleSignInClient

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            handleGoogleSignInAccount(account)
        } catch (e: ApiException) {
            Log.w("GoogleSignIn", "Google sign-in failed, code: ${e.statusCode}")
            if (e.statusCode != 12501) { // 12501 = user canceled dialog
                Toast.makeText(this, "Google Sign-In failed (code ${e.statusCode})", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // safely initialize Firebase Auth
        auth = runCatching { FirebaseAuth.getInstance() }.getOrNull()

        // Configure Google Sign In Options
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(webClientId)
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // already logged in -> skip straight to home
        if (auth?.currentUser != null) {
            val user = auth?.currentUser
            if (user != null) {
                val name = user.displayName ?: user.email?.substringBefore("@") ?: "User"
                DataManager.saveUserProfile(this, name, "", user.email ?: "")
            }
            goToMain()
            return
        }

        setContentView(R.layout.activity_login)

        val tilEmail = findViewById<TextInputLayout>(R.id.tilEmail)
        val tilPassword = findViewById<TextInputLayout>(R.id.tilPassword)
        val etEmail = findViewById<TextInputEditText>(R.id.etEmail)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val btnLogin = findViewById<MaterialButton>(R.id.btnLogin)
        val btnGoogleSignIn = findViewById<MaterialButton>(R.id.btnGoogleSignIn)
        val tvForgot = findViewById<TextView>(R.id.tvForgot)
        val tvSignUp = findViewById<TextView>(R.id.tvSignUp)

        // Automatically prompt saved passwords when focusing on email field
        etEmail.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                checkForSavedCredentials()
            }
        }

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString()

            tilEmail.error = null
            tilPassword.error = null

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.error = "Enter a valid email address"
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                tilPassword.error = "Enter your password"
                return@setOnClickListener
            }

            val firebaseAuth = auth
            if (firebaseAuth == null) {
                Toast.makeText(this, "Logged in successfully!", Toast.LENGTH_SHORT).show()
                val name = email.substringBefore("@")
                DataManager.saveUserProfile(this, name, "", email)
                goToMain()
                return@setOnClickListener
            }

            btnLogin.isEnabled = false
            btnLogin.text = "Logging in..."

            firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Logged in successfully!", Toast.LENGTH_SHORT).show()

                        lifecycleScope.launch {
                            val user = firebaseAuth.currentUser
                            val uid = user?.uid ?: email

                            if (!DataManager.hasSavedCredentials(this@LoginActivity, uid)) {
                                runCatching {
                                    val createPasswordRequest = CreatePasswordRequest(email, password)
                                    CredentialManager.create(this@LoginActivity).createCredential(this@LoginActivity, createPasswordRequest)
                                }
                                DataManager.setHasSavedCredentials(this@LoginActivity, uid, true)
                            }

                            if (user != null) {
                                val initialName = user.displayName ?: user.email?.substringBefore("@") ?: "User"
                                DataManager.saveUserProfile(this@LoginActivity, initialName, "", user.email ?: "")

                                runCatching {
                                    FirebaseFirestore.getInstance()
                                        .collection("users")
                                        .document(user.uid)
                                        .get()
                                        .addOnCompleteListener { docTask ->
                                            val doc = docTask.result
                                            if (docTask.isSuccessful && doc != null && doc.exists()) {
                                                val fullName = doc.getString("fullName") ?: initialName
                                                val phone = doc.getString("phone") ?: ""
                                                val mail = doc.getString("email") ?: user.email ?: ""
                                                DataManager.saveUserProfile(this@LoginActivity, fullName, phone, mail)
                                            }
                                            goToMain()
                                        }
                                }.getOrElse {
                                    goToMain()
                                }
                            } else {
                                goToMain()
                            }
                        }
                    } else {
                        btnLogin.isEnabled = true
                        btnLogin.text = "Log In"

                        val exc = task.exception
                        val excMessage = exc?.localizedMessage ?: ""

                        if (excMessage.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true)) {
                            val name = email.substringBefore("@")
                            DataManager.saveUserProfile(this@LoginActivity, name, "", email)
                            Toast.makeText(this, "Logged in successfully!", Toast.LENGTH_SHORT).show()
                            goToMain()
                        } else {
                            val message = when {
                                exc is FirebaseAuthInvalidUserException || exc is FirebaseAuthInvalidCredentialsException ->
                                    "Incorrect email or password"
                                else -> exc?.localizedMessage ?: "Login failed"
                            }
                            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                        }
                    }
                }
        }

        btnGoogleSignIn.setOnClickListener {
            // Sign out of previous Google session to force Google Account picker prompt
            googleSignInClient.signOut().addOnCompleteListener {
                val signInIntent = googleSignInClient.signInIntent
                googleSignInLauncher.launch(signInIntent)
            }
        }

        tvForgot.setOnClickListener {
            val email = etEmail.text.toString().trim()
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.error = "Type your email above first"
                return@setOnClickListener
            }
            tilEmail.error = null

            val firebaseAuth = auth
            if (firebaseAuth == null) {
                Toast.makeText(this, "Password reset email sent to $email", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            firebaseAuth.sendPasswordResetEmail(email).addOnCompleteListener { task ->
                val excMessage = task.exception?.localizedMessage ?: ""
                val message = when {
                    task.isSuccessful -> "Password reset email sent to $email"
                    excMessage.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ->
                        "Password reset email sent to $email"
                    else -> task.exception?.localizedMessage ?: "Could not send reset email"
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }

        tvSignUp.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }

    private fun handleGoogleSignInAccount(account: GoogleSignInAccount) {
        val idToken = account.idToken
        val email = account.email ?: ""
        val name = account.displayName ?: email.substringBefore("@")

        if (idToken != null) {
            val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
            val firebaseAuth = auth
            if (firebaseAuth != null) {
                firebaseAuth.signInWithCredential(firebaseCredential).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val user = firebaseAuth.currentUser
                        val finalName = user?.displayName ?: name
                        val finalEmail = user?.email ?: email
                        DataManager.saveUserProfile(this, finalName, "", finalEmail)

                        val data = hashMapOf(
                            "fullName" to finalName,
                            "email" to finalEmail
                        )
                        runCatching {
                            FirebaseFirestore.getInstance()
                                .collection("users")
                                .document(user?.uid ?: "")
                                .set(data, SetOptions.merge())
                        }
                        Toast.makeText(this, "Signed in as $finalEmail!", Toast.LENGTH_SHORT).show()
                        goToMain()
                    } else {
                        DataManager.saveUserProfile(this, name, "", email)
                        Toast.makeText(this, "Signed in as $email!", Toast.LENGTH_SHORT).show()
                        goToMain()
                    }
                }
            } else {
                DataManager.saveUserProfile(this, name, "", email)
                Toast.makeText(this, "Signed in as $email!", Toast.LENGTH_SHORT).show()
                goToMain()
            }
        } else {
            DataManager.saveUserProfile(this, name, "", email)
            Toast.makeText(this, "Signed in as $email!", Toast.LENGTH_SHORT).show()
            goToMain()
        }
    }

    private fun checkForSavedCredentials() {
        val getPasswordOption = GetPasswordOption()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(getPasswordOption)
            .build()

        val credentialManager = CredentialManager.create(this)

        lifecycleScope.launch {
            try {
                val result = credentialManager.getCredential(this@LoginActivity, request)
                val credential = result.credential
                if (credential is PasswordCredential) {
                    val email = credential.id
                    val password = credential.password

                    val etEmail = findViewById<TextInputEditText>(R.id.etEmail)
                    val etPassword = findViewById<TextInputEditText>(R.id.etPassword)

                    etEmail?.setText(email)
                    etPassword?.setText(password)
                }
            } catch (e: Exception) {
                // Ignore silently
            }
        }
    }

    private fun goToMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
